document.message.innerHTML = "External AND zipped!"
